import Head from './components/Head'
import Image from './components/Image'
import Foter from './components/Foter'
function App() {

  return (
    <>
      <Head/>
      <Image/>
      <Foter/>
    </>
  )
}

export default App