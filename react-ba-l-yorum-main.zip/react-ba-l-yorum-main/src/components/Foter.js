import React from 'react'
function Foter() {

  return (
    <footer>
        
    </footer>
  )
}

export default Foter