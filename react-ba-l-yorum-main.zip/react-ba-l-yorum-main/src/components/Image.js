import React from 'react'
import './images.css'
function Image() {
  return (
    <div>
       
    </div>
    
  )
}

export default Image